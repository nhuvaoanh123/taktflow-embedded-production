"""RTE model unit tests"""
