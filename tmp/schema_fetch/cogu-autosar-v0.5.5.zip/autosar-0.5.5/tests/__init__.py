"""
Python AUTOSAR unit tests
"""
