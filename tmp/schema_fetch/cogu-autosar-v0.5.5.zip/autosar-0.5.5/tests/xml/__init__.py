"""
AUTOSAR XML unit tests
"""
