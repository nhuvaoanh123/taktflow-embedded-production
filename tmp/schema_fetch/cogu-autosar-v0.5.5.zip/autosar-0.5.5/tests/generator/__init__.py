"""Code generator unit tests"""
